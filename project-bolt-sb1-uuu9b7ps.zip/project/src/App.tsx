import React from 'react';
import { Github, Linkedin, Mail, ExternalLink, Shield, Terminal, Brain, Lock, Server, Bug } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      {/* Hero Section */}
      <header className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Cyber Security Professional
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8">
              BSc (Hons) in Cyber Security and Ethical Hacking | Coventry University, UK
            </p>
            <div className="flex justify-center gap-4">
              <a href="https://github.com" className="p-2 hover:text-blue-400 transition-colors">
                <Github size={24} />
              </a>
              <a href="https://linkedin.com" className="p-2 hover:text-blue-400 transition-colors">
                <Linkedin size={24} />
              </a>
              <a href="mailto:contact@example.com" className="p-2 hover:text-blue-400 transition-colors">
                <Mail size={24} />
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Skills Section */}
      <section className="py-20 bg-gray-900/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Skills & Expertise</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-lg bg-gray-800/50 backdrop-blur-sm">
              <Shield className="w-12 h-12 mb-4 text-blue-400" />
              <h3 className="text-xl font-semibold mb-2">Security Assessment</h3>
              <p className="text-gray-400">VAPT, Network Security, Malware Analysis, Bug Bounty</p>
            </div>
            <div className="p-6 rounded-lg bg-gray-800/50 backdrop-blur-sm">
              <Terminal className="w-12 h-12 mb-4 text-purple-400" />
              <h3 className="text-xl font-semibold mb-2">Technical Skills</h3>
              <p className="text-gray-400">Python, Bash, PowerShell, C, Networking Protocols</p>
            </div>
            <div className="p-6 rounded-lg bg-gray-800/50 backdrop-blur-sm">
              <Brain className="w-12 h-12 mb-4 text-pink-400" />
              <h3 className="text-xl font-semibold mb-2">Reverse Engineering</h3>
              <p className="text-gray-400">Ghidra, x64dbg, PEStudio, FLARE VM</p>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Featured Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="group relative overflow-hidden rounded-lg bg-gray-800/50 p-6">
              <Lock className="w-12 h-12 mb-4 text-blue-400" />
              <h3 className="text-xl font-semibold mb-2">VulnReact Security Assessment</h3>
              <p className="text-gray-300 mb-4">
                Discovered and reported multiple critical vulnerabilities including NoSQLi, Stored XSS, and Broken Access Control.
                Provided detailed exploitation steps and remediation guidance.
              </p>
              <div className="flex gap-2 flex-wrap">
                <span className="px-3 py-1 bg-blue-500/20 rounded-full text-sm">NoSQLi</span>
                <span className="px-3 py-1 bg-blue-500/20 rounded-full text-sm">XSS</span>
                <span className="px-3 py-1 bg-blue-500/20 rounded-full text-sm">Access Control</span>
              </div>
            </div>
            
            <div className="group relative overflow-hidden rounded-lg bg-gray-800/50 p-6">
              <Server className="w-12 h-12 mb-4 text-purple-400" />
              <h3 className="text-xl font-semibold mb-2">Snort IPS Implementation</h3>
              <p className="text-gray-300 mb-4">
                Designed and implemented a comprehensive firewall with IDS/IPS capabilities using Snort.
                Focused on real-time packet inspection and threat mitigation.
              </p>
              <div className="flex gap-2 flex-wrap">
                <span className="px-3 py-1 bg-purple-500/20 rounded-full text-sm">Snort</span>
                <span className="px-3 py-1 bg-purple-500/20 rounded-full text-sm">IDS/IPS</span>
                <span className="px-3 py-1 bg-purple-500/20 rounded-full text-sm">Firewall</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-20 bg-gray-900/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Certifications</h2>
          <div className="max-w-2xl mx-auto">
            <div className="flex flex-col gap-6">
              <div className="p-6 rounded-lg bg-gray-800/50 backdrop-blur-sm flex items-center gap-4">
                <Shield className="w-8 h-8 text-green-400 flex-shrink-0" />
                <div>
                  <h3 className="text-xl font-semibold">NSE 1 – Network Security Associate</h3>
                  <p className="text-gray-400">Fortinet</p>
                </div>
              </div>
              <div className="p-6 rounded-lg bg-gray-800/50 backdrop-blur-sm flex items-center gap-4">
                <Lock className="w-8 h-8 text-green-400 flex-shrink-0" />
                <div>
                  <h3 className="text-xl font-semibold">ISC2 Certified in Cybersecurity</h3>
                  <p className="text-gray-400">ISC2</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Current Focus Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Current Focus</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-lg bg-gray-800/50 backdrop-blur-sm">
              <Bug className="w-12 h-12 mb-4 text-red-400" />
              <h3 className="text-xl font-semibold mb-2">Exploit Development</h3>
              <p className="text-gray-400">Learning advanced exploit development and malware analysis techniques</p>
            </div>
            <div className="p-6 rounded-lg bg-gray-800/50 backdrop-blur-sm">
              <Shield className="w-12 h-12 mb-4 text-yellow-400" />
              <h3 className="text-xl font-semibold mb-2">Bug Bounty</h3>
              <p className="text-gray-400">Active participation in bug bounty programs to build real-world skills</p>
            </div>
            <div className="p-6 rounded-lg bg-gray-800/50 backdrop-blur-sm">
              <Brain className="w-12 h-12 mb-4 text-blue-400" />
              <h3 className="text-xl font-semibold mb-2">Further Education</h3>
              <p className="text-gray-400">Planning for a Master's in IT to deepen expertise and research skills</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gray-900/50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8">Let's Connect</h2>
            <p className="text-gray-300 mb-8">
              I'm always open to exciting opportunities, collaborations, and learning from fellow security professionals. 
              Let's secure the world, one bug at a time!
            </p>
            <a
              href="mailto:contact@example.com"
              className="inline-flex items-center px-6 py-3 rounded-full bg-blue-500 hover:bg-blue-600 transition-colors"
            >
              <Mail className="mr-2" /> Get in Touch
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 text-center text-gray-400">
        <p>© {new Date().getFullYear()} All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;